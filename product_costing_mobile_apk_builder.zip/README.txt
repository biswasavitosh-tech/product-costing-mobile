PRODUCT COSTING MOBILE — ANDROID PROJECT

Included:
- Responsive product material and costing tool in app/src/main/assets/index.html
- Android WebView wrapper project
- Offline use; calculations and local browser storage work without internet

BUILD ON WINDOWS:
1. Install Android Studio (official): https://developer.android.com/studio
2. Extract this ZIP to a folder.
3. Open Android Studio > Open, and select the extracted ProductCostingMobile folder.
4. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35 and compatible Gradle/JDK tools.
5. To build an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When complete, click "locate" in the notification. The APK is usually at:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer the APK to your Android phone and install it. You may need to allow installing apps from that source.

QUICK MOBILE USE WITHOUT INSTALLING AN APK:
Open product_costing_calculator.html in Chrome on your phone. If your phone's file manager does not open it correctly, transfer the file to Google Drive or another file host and open it in the browser.

NOTES:
- Saved products are stored locally on the device/app WebView and are not automatically synced across devices.
- Export CSV is available from inside the tool.
- This project source is provided; an APK is not prebuilt here.
